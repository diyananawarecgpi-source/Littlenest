LITTLENEST - KIDS PRODUCTS STORE

RUN ON YOUR LAPTOP:
1. Extract this ZIP.
2. Open the folder in VS Code.
3. Open index.html.
4. Right-click and choose "Open with Live Server" (if installed), OR double-click index.html to open it in a browser.

PUBLISH ON GITHUB PAGES:
1. Create a NEW public GitHub repository, e.g. littlenest-kids-store.
2. Upload index.html to the ROOT of the repository (not inside another folder).
3. Open repository Settings -> Pages.
4. Under Build and deployment, choose "Deploy from a branch".
5. Select branch "main" and folder "/ (root)", then Save.
6. Wait for deployment, then open the website URL shown in Settings -> Pages.

FEATURES:
- Product cards, category filters, search, sort
- Add to cart, quantity controls, wishlist
- Demo COD checkout
- Cart and wishlist saved in this browser using localStorage

IMPORTANT:
This is a frontend demo/static site. It does NOT process real payments, save orders to an online database,
or send customer information to a store owner. Never collect real customer/payment details with this demo.
For real Razorpay payments and persistent orders, connect a secure backend and database.
Product photos load from Unsplash and require an internet connection.
